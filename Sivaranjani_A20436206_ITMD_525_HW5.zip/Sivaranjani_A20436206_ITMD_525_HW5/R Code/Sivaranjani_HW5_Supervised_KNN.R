# Sivaranjani_A20436206

#----------------------------------------------------------------------------------------------------------------------------------------------------
# KNN
#----------------------------------------------------------------------------------------------------------------------------------------------------

#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Assignment/Assignment 5/')

# Loading data from CSV file
Zoo_Data=read.csv('W5_zoo.csv',header=T)

# Checking for missing values
nrow(is.na(Zoo_Data))

# Removing ID column 
Zoo_Data = Zoo_Data[,-1]

head(Zoo_Data)
str(Zoo_Data)

# Converting label attribute from nominal to numerical
install.packages("plyr")
library(plyr)

Zoo_Data[,17]=factor(Zoo_Data[,17])
Zoo_Data$type=revalue(Zoo_Data$type,c("1"="Type-1"))
Zoo_Data$type=revalue(Zoo_Data$type,c("2"="Type-2"))
Zoo_Data$type=revalue(Zoo_Data$type,c("3"="Type-3"))
Zoo_Data$type=revalue(Zoo_Data$type,c("4"="Type-4"))
Zoo_Data$type=revalue(Zoo_Data$type,c("5"="Type-5"))
Zoo_Data$type=revalue(Zoo_Data$type,c("6"="Type-6"))
Zoo_Data$type=revalue(Zoo_Data$type,c("7"="Type-7"))

# Normalizing independent attributes
num_vars=sapply(Zoo_Data,is.numeric)
Zoo_Data[num_vars]=lapply(Zoo_Data[num_vars],scale)
summary(Zoo_Data)


# installing required packages for KNN
install.packages('caret', dependencies = TRUE)
library(caret)

#----------------------------------------------------------
# KNN - Full Model 
#----------------------------------------------------------
# Classifying and assigning dependent and independent attributes
subset=c("hair","feathers","eggs","milk","airborne","aquatic","predator","toothed","backbone","breathes","venomous","fins","legs","tail","domestic","catsize")
x=Zoo_Data[subset]
y=Zoo_Data$type

# Executing KNN for dependent and independent for K values from 1 to 10
# Implemented N(5) Fold cross validation of 
KNN_M1=train(x,y,'knn',trControl = trainControl(method = 'cv',number = 5),tuneGrid = expand.grid(k=1:10))
print(KNN_M1)

# Feature Selection
set.seed(7)
install.packages("mlbench")
library(mlbench)

# Feature Selection - Wrapper Method
control=rfeControl(functions = rfFuncs,method = "cv",number = 5)
Features_Select=rfe(Zoo_Data[,1:16],Zoo_Data[,17],sizes = c(1:16),rfeControl = control)
print(Features_Select)
predictors(Features_Select)
plot(Features_Select, type = c("g","o"))


# implementing features selected from FS

#----------------------------------------------------------
# KNN -  Model with Top5 features from FS (milk, feathers, toothed, backbone, eggs)
#----------------------------------------------------------
subset_FS1=c("feathers","eggs","milk","toothed","backbone")
x1=Zoo_Data[subset_FS]
y1=Zoo_Data$type

# Executing KNN for dependent and independent for K values from 1 to 10
# Implemented N(5) Fold cross validation of 
KNN_M2_FS=train(x1,y1,'knn',trControl = trainControl(method = 'cv',number = 5),tuneGrid = expand.grid(k=1:10))
print(KNN_M2_FS)


#--------------------------------------------------------------------------------------------------------------------
# KNN -  Model with Top7 features from FS (hair,milk, feathers, toothed, backbone, eggs,breathes)
#--------------------------------------------------------------------------------------------------------------------

subset_FS2=c("hair","feathers","eggs","milk","toothed","backbone","breathes")
x2=Zoo_Data[subset_FS2]
y2=Zoo_Data$type

# Executing KNN for dependent and independent for K values from 1 to 10
# Implemented N(5) Fold cross validation of 
KNN_M2_FS=train(x2,y2,'knn',trControl = trainControl(method = 'cv',number = 5),tuneGrid = expand.grid(k=1:10))
print(KNN_M2_FS)


#----------------------------------------------------------
# KNN -  Model with Top10 features from FS (hair,milk, feathers, toothed, backbone, eggs,breathes)
#----------------------------------------------------------
# Classifying and assigning dependent and independent attributes
subset_FS3=c("hair","feathers","eggs","milk","toothed","backbone","breathes","fins","legs","tail")
x3=Zoo_Data[subset_FS3]
y3=Zoo_Data$type

# Executing KNN for dependent and independent for K values from 1 to 10
# Implemented N(5) Fold cross validation of 
KNN_M3_FS=train(x3,y3,'knn',trControl = trainControl(method = 'cv',number = 5),tuneGrid = expand.grid(k=1:10))
print(KNN_M3_FS)

#----------------------------------------------------------
# KNN -  Model with Top3 features from FS (milk, feathers, toothed, backbone, eggs)
#----------------------------------------------------------
subset_FS4=c("feathers","eggs","milk")
x4=Zoo_Data[subset_FS4]
y4=Zoo_Data$type

# Executing KNN for dependent and independent for K values from 1 to 10
# Implemented N(5) Fold cross validation of 
KNN_M4_FS=train(x4,y4,'knn',trControl = trainControl(method = 'cv',number = 5),tuneGrid = expand.grid(k=1:10))
print(KNN_M4_FS)


