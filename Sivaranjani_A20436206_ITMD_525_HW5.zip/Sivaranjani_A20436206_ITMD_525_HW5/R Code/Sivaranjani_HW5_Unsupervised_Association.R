#----------------------------------------------------------------------------------------------------------------------------------------------------
# Association Rules
#----------------------------------------------------------------------------------------------------------------------------------------------------
# Sivaranjani_A20436206
#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Assignment/Assignment 5/')

# Loading data from CSV file
Bank_Data=read.csv('W7_BankData.csv',header=T) 

# Checking for missing values
nrow(is.na(Bank_Data))

# Removing ID column 
Bank_Data = Bank_Data[,-1]
head(Bank_Data)
class(Bank_Data)

# Data preprocessing - converting numerical features to categorical ones

Bank_Data$age=cut(Bank_Data$age,breaks = c(17,25,40,60,80),labels=c("Young","Adult","Middle-Aged","Senior"),right=FALSE)
Bank_Data$income=cut(Bank_Data$income,breaks = c(5000.00,15000.00,30000.00,50000.00,62000.00),labels=c("Entry-level","Middle","Upper-Middle","High"),right=FALSE)
Bank_Data$children=cut(Bank_Data$children,breaks = c(0,1,2,3,10),labels=c("No","One","Two","More than 2"),right=FALSE)

#----------------------------------------------------------------------------------------------------------------------------------------------------
# Association Rules without converting into transactional data type
#----------------------------------------------------------------------------------------------------------------------------------------------------
install.packages("arules")
library(arules)
install.packages("arulesViz")
library(arulesViz)

data("Bank_Data")
# Giving support value as 40% and confidence level as 70%
Bank_Assoc_Rules=apriori(Bank_Data,parameter = list(support=0.04,confidence=0.7))
# Inspecting top 4 elements with 40% and confidence level as 70%
inspect(head(sort(Bank_Assoc_Rules, by= "confidence"),4))

#----------------------------------------------------------------------------------------------------------------------------------------------------
# Association Rules converting into transactional data type using read trans
#----------------------------------------------------------------------------------------------------------------------------------------------------

Bank_Trans_Data = read.transactions("W7_BankData.csv", format = "single", header = TRUE,sep = ",", cols = c("id","age"))
class(Bank_Trans_Data)

Bank_Rules_Trans=apriori(Bank_Trans_Data,parameter = list(support=0.04,confidence=0.7))
inspect(head(sort(Bank_Rules_Trans, by= "confidence"),4))

#----------------------------------------------------------------------------------------------------------------------------------------------------
# Association Rules converting into transactional data type using lapply
#----------------------------------------------------------------------------------------------------------------------------------------------------

Bank = lapply(Bank_Data, function(x){as.factor(x)})
str(Bank)
class(Bank)
Bank_Trans_Data=as(Bank,"transactions")

Bank_R1=apriori(Bank_Trans_Data,parameter = list(support=0.01,confidence=0.5))
inspect(head(sort(Bank_R1, by= "confidence"),4))
