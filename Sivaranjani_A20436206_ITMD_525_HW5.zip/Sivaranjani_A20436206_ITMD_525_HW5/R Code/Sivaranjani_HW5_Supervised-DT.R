#----------------------------------------------------------------------------------------------------------------------------------------------------
# Decision Tree
#----------------------------------------------------------------------------------------------------------------------------------------------------

# Sivaranjani_A20436206
#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Assignment/Assignment 5/')

# Loading data from CSV file
Zoo_Data=read.csv('W5_zoo.csv',header=T)

# Checking for missing values
nrow(is.na(Zoo_Data))
head(Zoo_Data)
set.seed(3233)
Zoo_Data=Zoo_Data[,-1]

# installing required packages for Decision Tree
install.packages('caret', dependencies = TRUE)
library(caret)

# Converting numerical to categorical data
Zoo_Data$hair=cut(Zoo_Data$hair,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$feathers=cut(Zoo_Data$feathers,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$eggs=cut(Zoo_Data$eggs,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$milk=cut(Zoo_Data$milk,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$airborne=cut(Zoo_Data$airborne,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$aquatic=cut(Zoo_Data$aquatic,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$predator=cut(Zoo_Data$predator,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$toothed=cut(Zoo_Data$toothed,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$backbone=cut(Zoo_Data$backbone,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$breathes=cut(Zoo_Data$breathes,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$venomous=cut(Zoo_Data$venomous,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$fins=cut(Zoo_Data$fins,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$tail=cut(Zoo_Data$tail,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$domestic=cut(Zoo_Data$domestic,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$catsize=cut(Zoo_Data$catsize,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$legs=cut(Zoo_Data$legs,breaks = c(0,2,4,5,6,8,10),labels=c("Zero","Two","Four","Five","Six","Eight"),right=FALSE)
Zoo_Data$type=cut(Zoo_Data$type,breaks = c(1,2,3,4,5,6,7,8),labels=c("One","Two","Three","Four","Five","Six","Seven"),right=FALSE)

#--------------------------------------------------------------------------------------------------------------------
# Decision Tree - Full Model 
#--------------------------------------------------------------------------------------------------------------------
DTree_M1=train(type~hair+feathers+eggs+milk+airborne+aquatic+predator+toothed+backbone+breathes+venomous+fins+legs+tail+domestic+catsize, data = Zoo_Data, method = "rpart", trControl=trainControl(method = "cv", number = 5), tuneLength = 10,parms=list(split="information"))
print(DTree_M1)

# Feature Selection - Wrapper Method
control=rfeControl(functions = rfFuncs,method = "cv",number = 5)
Features_Select=rfe(Zoo_Data[,1:16],Zoo_Data[,17],sizes = c(1:16),rfeControl = control)
print(Features_Select)
predictors(Features_Select)
plot(Features_Select, type = c("g","o"))

# implementing features selected from FS in Decision Tree

#--------------------------------------------------------------------------------------------------------------------
# Decision Tree -  Model with Top5 features from FS (milk, legs, toothed, eggs, feathers)
#--------------------------------------------------------------------------------------------------------------------
DTree_M2_FS=train(type~feathers+eggs+milk+toothed+legs, data = Zoo_Data, method = "rpart", trControl=trainControl(method = "cv", number = 5), tuneLength = 10,parms=list(split="information"))
print(DTree_M2_FS)

#--------------------------------------------------------------------------------------------------------------------
# Decision Tree -  Model with Top7 features from FS (milk, legs, toothed, eggs, feathers, backbone,breathes)
#--------------------------------------------------------------------------------------------------------------------
DTree_M3_FS=train(type~feathers+eggs+milk+toothed+legs+backbone+breathes, data = Zoo_Data, method = "rpart", trControl=trainControl(method = "cv", number = 5), tuneLength = 10,parms=list(split="information"))
print(DTree_M3_FS)

#--------------------------------------------------------------------------------------------------------------------
# Decision Tree -  Model with Top10 features from FS (milk, legs, toothed, eggs, feathers, backbone,breathes)
#--------------------------------------------------------------------------------------------------------------------
DTree_M4_FS=train(type~hair+feathers+eggs+milk+toothed+backbone+breathes+fins+legs+tail, data = Zoo_Data, method = "rpart", trControl=trainControl(method = "cv", number = 5), tuneLength = 10,parms=list(split="information"))
print(DTree_M4_FS)

#--------------------------------------------------------------------------------------------------------------------
# Decision Tree -  Model with Top 3 features from FS (milk, legs, toothed, eggs, feathers, backbone,breathes)
#--------------------------------------------------------------------------------------------------------------------
DTree_M5_FS=train(type~milk+toothed+legs, data = Zoo_Data, method = "rpart", trControl=trainControl(method = "cv", number = 5), tuneLength = 10,parms=list(split="information"))
print(DTree_M5_FS)
