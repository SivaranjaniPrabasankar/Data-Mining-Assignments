#----------------------------------------------------------------------------------------------------------------------------------------------------
# K-Means
#----------------------------------------------------------------------------------------------------------------------------------------------------
# Sivaranjani_A20436206
#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Assignment/Assignment 5/')

# Loading data from CSV file
Zoo_Data=read.csv('W5_zoo.csv',header=T)

# Checking for missing values
nrow(is.na(Zoo_Data))

# Removing ID column 
Zoo_Data = Zoo_Data[,-1]
Zoo_Data = Zoo_Data[,-17]
head(Zoo_Data)

# Normalizing independent attributes
num_vars=sapply(Zoo_Data,is.numeric)
Zoo_Data[num_vars]=lapply(Zoo_Data[num_vars],scale)
summary(Zoo_Data)

# installing required packages
install.packages("dummies", dependencies = TRUE)
library(dummies)
Zoo_Data = dummy.data.frame(Zoo_Data, names = c("hair","feathers","eggs","milk","airborne","aquatic","predator","toothed","backbone","breathes","venomous","fins","legs","tail","domestic","catsize","type"),sep = ".")
install.packages("cluster", dependencies = TRUE)
library(cluster)
install.packages("factoextra", dependencies = TRUE)
library(factoextra)

# Making 5 clusters using k -means
kmeans_res=kmeans(Zoo_Data,5)
kmeans_res$cluster
kmeans_res$size
kmeans_res$centers

# Plot the clusters
plot(Zoo_Data,col=kmeans_res$cluster, pch=29, frame=FALSE,main="K Means with K=5")
points(kmeans_res$cluster, col=1:2, pch=8,cex=3)

