#----------------------------------------------------------------------------------------------------------------------------------------------------
# Support Vector Machine
#----------------------------------------------------------------------------------------------------------------------------------------------------
# Sivaranjani_A20436206
#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Assignment/Assignment 5/')

# Loading data from CSV file
Zoo_Data=read.csv('W5_zoo.csv',header=T)

# Checking for missing values
nrow(is.na(Zoo_Data))

install.packages("e1071")
library(e1071)

set.seed(3233)

# installing required packages for SVM
install.packages('caret', dependencies = TRUE)
library(caret)

#----------------------------------------------------------
# SVM - Full Model 
#----------------------------------------------------------
# Classifying and assigning dependent and independent attributes
subset=c("hair","feathers","eggs","milk","airborne","aquatic","predator","toothed","backbone","breathes","venomous","fins","legs","tail","domestic","catsize")
x1=Zoo_Data[subset]
y1=Zoo_Data$type

# Executing SVM for dependent and independent attributes
# Implemented N(5) Fold cross validation of 
SVM_M1 = train(x1,y1, data = Zoo_Data, method = "svmLinear", trControl=trainControl(method = "cv", number = 5), tuneLength = 10)
print(SVM_M1)


control=rfeControl(functions = rfFuncs,method = "cv",number = 5)
Features_Select=rfe(Zoo_Data[,1:16],Zoo_Data[,17],sizes = c(1:16),rfeControl = control)
print(Features_Select)
predictors(Features_Select)
plot(Features_Select, type = c("g","o"))

# implementing features selected from FS in SVM 
#--------------------------------------------------------------------------------------------------------------------
#  SVM  -  Model with Top5 features from FS (backbone, milk, tail, eggs, legs)
#--------------------------------------------------------------------------------------------------------------------
subset_FS1=c("eggs","milk","backbone","legs","tail")
x2=Zoo_Data[subset_FS1]
y2=Zoo_Data$type

SVM_M2_FS = train(x2,y2, data = Zoo_Data, method = "svmLinear", trControl=trainControl(method = "cv", number = 5), tuneLength = 10)
print(SVM_M2_FS)

#--------------------------------------------------------------------------------------------------------------------
#  SVM  -  Model with Top7 features from FS 
#--------------------------------------------------------------------------------------------------------------------
subset_FS2=c("eggs","milk","backbone","legs","tail","hair","feathers")
x3=Zoo_Data[subset_FS2]
y3=Zoo_Data$type

SVM_M3_FS = train(x3,y3, data = Zoo_Data, method = "svmLinear", trControl=trainControl(method = "cv", number = 5), tuneLength = 10)
print(SVM_M3_FS)

#--------------------------------------------------------------------------------------------------------------------
#  SVM  -  Model with Top10 features from FS 
#--------------------------------------------------------------------------------------------------------------------
subset_FS3=c("eggs","milk","backbone","legs","tail","hair","feathers","breathes","toothed","fins")
x3=Zoo_Data[subset_FS3]
y3=Zoo_Data$type

SVM_M4_FS = train(x4,y4, data = Zoo_Data, method = "svmLinear", trControl=trainControl(method = "cv", number = 5), tuneLength = 10)
print(SVM_M4_FS)

#--------------------------------------------------------------------------------------------------------------------
#  SVM  -  Model with Top3 features from FS 
#--------------------------------------------------------------------------------------------------------------------
subset_FS4=c("milk","backbone","tail")
x4=Zoo_Data[subset_FS4]
y4=Zoo_Data$type

SVM_M5_FS = train(x5,y5, data = Zoo_Data, method = "svmLinear", trControl=trainControl(method = "cv", number = 5), tuneLength = 10)
print(SVM_M5_FS)

