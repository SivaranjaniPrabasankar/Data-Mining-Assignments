#----------------------------------------------------------------------------------------------------------------------------------------------------
# Naive Bayes
#----------------------------------------------------------------------------------------------------------------------------------------------------
# Sivaranjani_A20436206
#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Assignment/Assignment 5/')

# Loading data from CSV file
Zoo_Data=read.csv('W5_zoo.csv',header=T)

# Checking for missing values
nrow(is.na(Zoo_Data))

# Removing ID column 
Zoo_Data = Zoo_Data[,-1]

str(Zoo_Data)
head(Zoo_Data)

# Data preprocessing - converting numerical features to categorical ones

Zoo_Data$hair=cut(Zoo_Data$hair,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$feathers=cut(Zoo_Data$feathers,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$eggs=cut(Zoo_Data$eggs,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$milk=cut(Zoo_Data$milk,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$airborne=cut(Zoo_Data$airborne,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$aquatic=cut(Zoo_Data$aquatic,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$predator=cut(Zoo_Data$predator,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$toothed=cut(Zoo_Data$toothed,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$backbone=cut(Zoo_Data$backbone,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$breathes=cut(Zoo_Data$breathes,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$venomous=cut(Zoo_Data$venomous,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$fins=cut(Zoo_Data$fins,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$tail=cut(Zoo_Data$tail,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$domestic=cut(Zoo_Data$domestic,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$catsize=cut(Zoo_Data$catsize,breaks = c(0,1,2),labels=c("No","Yes"),right=FALSE)
Zoo_Data$legs=cut(Zoo_Data$legs,breaks = c(0,2,4,5,6,8,10),labels=c("Zero","Two","Four","Five","Six","Eight"),right=FALSE)

# Data preprocessing - converting numerical label features to categorical ones
install.packages("plyr")
library(plyr)

Zoo_Data[,17]=factor(Zoo_Data[,17])
Zoo_Data$type=revalue(Zoo_Data$type,c("1"="Type-1"))
Zoo_Data$type=revalue(Zoo_Data$type,c("2"="Type-2"))
Zoo_Data$type=revalue(Zoo_Data$type,c("3"="Type-3"))
Zoo_Data$type=revalue(Zoo_Data$type,c("4"="Type-4"))
Zoo_Data$type=revalue(Zoo_Data$type,c("5"="Type-5"))
Zoo_Data$type=revalue(Zoo_Data$type,c("6"="Type-6"))
Zoo_Data$type=revalue(Zoo_Data$type,c("7"="Type-7"))

head(Zoo_Data)
str(Zoo_Data)

# installing required packages for KNN
install.packages('caret', dependencies = TRUE)
library(caret)

#----------------------------------------------------------
# Naive Bayes - Full Model 
#----------------------------------------------------------
x=Zoo_Data[,-17]
y=Zoo_Data$type
NB_M1=suppressWarnings(train(x,y,'nb',laplace = 2,trControl = trainControl(method = 'cv',number = 5),na.action=na.pass))
print(NB_M1)


# Feature Selection - Wrapper Method
set.seed(7)
install.packages("mlbench")
library(mlbench)
library(caret)

control=rfeControl(functions = rfFuncs,method = "cv",number = 5)
Features_Select=rfe(Zoo_Data[,1:16],Zoo_Data[,17],sizes = c(1:16),rfeControl = control)
print(Features_Select)
predictors(Features_Select)
plot(Features_Select, type = c("g","o"))

# implementing features selected from FS in  Naive Bayes 

#--------------------------------------------------------------------------------------------------------------------
#  Naive Bayes  -  Model with Top5 features from FS (milk, legs, toothed, eggs, feathers)
#--------------------------------------------------------------------------------------------------------------------

subset_FS1=c("hair","feathers","eggs","milk","toothed","legs")
x1=Zoo_Data[subset_FS1]
y1=Zoo_Data$type

NB_M2_FS=suppressWarnings(train(x1,y1,'nb',laplace = 2,trControl = trainControl(method = 'cv',number = 5),na.action=na.pass))
print(NB_M2_FS)

#--------------------------------------------------------------------------------------------------------------------
#  Naive Bayes  -  Model with Top7 features from FS (milk, legs, toothed, eggs, feathers)
#--------------------------------------------------------------------------------------------------------------------
subset_FS2=c("hair","feathers","eggs","milk","toothed","legs","backbone","breathes")
x2=Zoo_Data[subset_FS2]
y2=Zoo_Data$type

NB_M3_FS=suppressWarnings(train(x2,y2,'nb',laplace = 2,trControl = trainControl(method = 'cv',number = 5),na.action=na.pass))
print(NB_M3_FS)

#--------------------------------------------------------------------------------------------------------------------
#  Naive Bayes  -  Model with Top 10 features from FS
#--------------------------------------------------------------------------------------------------------------------

subset_FS3=c("hair","feathers","eggs","milk","toothed","backbone","breathes","fins","legs","tail")
x3=Zoo_Data[subset_FS3]
y3=Zoo_Data$type
NB_M4_FS=suppressWarnings(train(x3,y3,'nb',laplace = 2,trControl = trainControl(method = 'cv',number = 5),na.action=na.pass))
print(NB_M4_FS)

#--------------------------------------------------------------------------------------------------------------------
#  Naive Bayes  -  Model with Top 3 features from FS 
#--------------------------------------------------------------------------------------------------------------------

subset_FS4=c("milk","toothed","legs")
x4=Zoo_Data[subset_FS4]
y4=Zoo_Data$type
NB_M5_FS=suppressWarnings(train(x4,y4,'nb',laplace = 2,trControl = trainControl(method = 'cv',number = 5),na.action=na.pass))
print(NB_M5_FS)