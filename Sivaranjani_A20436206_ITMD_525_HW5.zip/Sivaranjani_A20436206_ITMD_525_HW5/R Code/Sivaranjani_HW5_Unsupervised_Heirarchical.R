#----------------------------------------------------------------------------------------------------------------------------------------------------
# Hierarchical Clustering 
#----------------------------------------------------------------------------------------------------------------------------------------------------
# Sivaranjani_A20436206
#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Fall-19/Data Mining/Assignment/Assignment 5/')

# Loading data from CSV file
Zoo_Data=read.csv('W5_zoo.csv',header=T)

# Checking for missing values
nrow(is.na(Zoo_Data))

# Removing ID column 
Zoo_Data = Zoo_Data[,-1]
head(Zoo_Data)

#----------------------------------------------------------------------------------------------------------------------------------------------------
# Hierarchical Clustering using Euclidean Distance
#----------------------------------------------------------------------------------------------------------------------------------------------------
H_Cluster1 = dist(Zoo_Data,method="euclidean")
H_Tree1 = hclust(H_Cluster1,method = "ward.D")
plot(H_Tree1)
groups=cutree(H_Tree1,k=5)
rect.hclust(H_Tree1,k=5,border = "red")

#----------------------------------------------------------------------------------------------------------------------------------------------------
# Hierarchical Clustering using  Manhattan Distance
#----------------------------------------------------------------------------------------------------------------------------------------------------
H_Cluster2 = dist(Zoo_Data,method="manhattan")
H_Tree2 = hclust(H_Cluster2,method = "ward.D")
plot(H_Tree2)
group_2=cutree(H_Tree2,k=5)
rect.hclust(H_Tree2,k=5,border = "blue")
